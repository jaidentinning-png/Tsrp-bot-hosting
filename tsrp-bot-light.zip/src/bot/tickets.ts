import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type ChatInputCommandInteraction,
  type Guild,
  type GuildMember,
  PermissionFlagsBits,
  type User,
} from "discord.js";
import { db, ticketsTable, type TicketPanel } from "../db/index.js";
import { and, eq } from "drizzle-orm";
import { getGuildConfig } from "./config";
import { baseEmbed } from "./utils";

export function buildTicketPanelMessage(panel: TicketPanel) {
  const embed = baseEmbed(panel.color).setTitle(panel.title).setDescription(panel.description);

  const buttons = panel.categories.map((cat) =>
    new ButtonBuilder()
      .setCustomId(`ticket_open:${panel.id}:${cat.id}`)
      .setLabel(cat.label)
      .setEmoji(cat.emoji || "🎫")
      .setStyle(ButtonStyle.Primary),
  );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(buttons);
  return { embeds: [embed], components: [row] };
}

export async function openTicket(
  guild: Guild,
  user: User,
  panel: TicketPanel,
  categoryId: string,
): Promise<{ success: boolean; message: string }> {
  const category = panel.categories.find((c) => c.id === categoryId);
  if (!category) return { success: false, message: "That ticket category no longer exists." };

  const config = await getGuildConfig(guild.id);

  const existing = await db
    .select()
    .from(ticketsTable)
    .where(and(eq(ticketsTable.guildId, guild.id), eq(ticketsTable.userId, user.id), eq(ticketsTable.status, "open")))
    .limit(5);

  if (existing.length >= 3) {
    return { success: false, message: "You already have 3 open tickets. Please close one before opening another." };
  }

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
  ];
  if (config.staffRoleId) {
    overwrites.push({
      id: config.staffRoleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const channel = await guild.channels.create({
    name: `ticket-${user.username}`.toLowerCase().slice(0, 90),
    parent: config.ticketCategoryId ?? undefined,
    permissionOverwrites: overwrites,
  });

  const [ticket] = await db
    .insert(ticketsTable)
    .values({
      guildId: guild.id,
      panelId: panel.id,
      categoryLabel: category.label,
      channelId: channel.id,
      userId: user.id,
      status: "open",
    })
    .returning();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`ticket_claim:${ticket?.id}`).setLabel("Claim").setStyle(ButtonStyle.Secondary).setEmoji("🙋"),
    new ButtonBuilder().setCustomId(`ticket_close:${ticket?.id}`).setLabel("Close").setStyle(ButtonStyle.Danger).setEmoji("🔒"),
  );

  const embed = baseEmbed(config.embedColor)
    .setTitle(`${category.label}`)
    .setDescription(`Hi <@${user.id}>, thanks for opening a ticket.\n\n${category.description}\n\nStaff will be with you shortly.`);

  await channel.send({ content: config.staffRoleId ? `<@&${config.staffRoleId}>` : undefined, embeds: [embed], components: [row] });

  return { success: true, message: `Ticket created: <#${channel.id}>` };
}

export async function claimTicket(interaction: { guild: Guild | null; user: User; channelId: string }, ticketId: number) {
  const [ticket] = await db.select().from(ticketsTable).where(eq(ticketsTable.id, ticketId)).limit(1);
  if (!ticket) return null;
  const [updated] = await db
    .update(ticketsTable)
    .set({ claimedBy: interaction.user.id, status: "claimed" })
    .where(eq(ticketsTable.id, ticketId))
    .returning();
  return updated;
}

export async function closeTicket(
  guild: Guild,
  member: GuildMember,
  ticketId: number,
  transcript: string,
): Promise<void> {
  const [ticket] = await db.select().from(ticketsTable).where(eq(ticketsTable.id, ticketId)).limit(1);
  if (!ticket) return;

  await db
    .update(ticketsTable)
    .set({ status: "closed", closedBy: member.id, closedAt: new Date(), transcript })
    .where(eq(ticketsTable.id, ticketId));

  const config = await getGuildConfig(guild.id);
  if (config.ticketLogChannelId) {
    const logChannel = await guild.channels.fetch(config.ticketLogChannelId).catch(() => null);
    if (logChannel?.isTextBased()) {
      const embed = baseEmbed(config.embedColor)
        .setTitle(`Ticket #${ticket.id} Closed`)
        .addFields(
          { name: "Opened By", value: `<@${ticket.userId}>`, inline: true },
          { name: "Closed By", value: `<@${member.id}>`, inline: true },
          { name: "Category", value: ticket.categoryLabel ?? "N/A", inline: true },
        )
        .setDescription(transcript.slice(0, 3800) || "No messages recorded.");
      await logChannel.send({ embeds: [embed] });
    }
  }
}

export async function getTicketByChannel(channelId: string) {
  const [ticket] = await db.select().from(ticketsTable).where(eq(ticketsTable.channelId, channelId)).limit(1);
  return ticket ?? null;
}
