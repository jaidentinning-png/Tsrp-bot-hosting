import { PermissionFlagsBits, SlashCommandBuilder } from "discord.js";
import { db, infractionsTable } from "../../db/index.js";
import { and, desc, eq } from "drizzle-orm";
import type { SlashCommand } from "../types";
import { getGuildConfig } from "../config";
import { baseEmbed } from "../utils";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("infractions")
    .setDescription("View or manage a user's infraction/moderation history")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((sub) =>
      sub
        .setName("history")
        .setDescription("View a user's infraction history")
        .addUserOption((opt) => opt.setName("user").setDescription("User to check").setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Void an infraction by ID")
        .addIntegerOption((opt) => opt.setName("id").setDescription("Infraction ID").setRequired(true)),
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      await interaction.reply({ content: "Server only.", ephemeral: true });
      return;
    }
    const sub = interaction.options.getSubcommand();
    const config = await getGuildConfig(interaction.guild.id);

    if (sub === "history") {
      const target = interaction.options.getUser("user", true);
      const records = await db
        .select()
        .from(infractionsTable)
        .where(and(eq(infractionsTable.guildId, interaction.guild.id), eq(infractionsTable.userId, target.id)))
        .orderBy(desc(infractionsTable.createdAt))
        .limit(20);

      if (records.length === 0) {
        await interaction.reply({
          content: `<@${target.id}> (\`${target.id}\`) has a clean record in this server.`,
          ephemeral: true,
        });
        return;
      }

      const embed = baseEmbed(config.embedColor)
        .setTitle(`Infraction History — ${target.username}`)
        .setDescription(
          records
            .map(
              (r) =>
                `${r.active ? "" : "~~"}**#${r.id} — ${r.type.toUpperCase()}**: ${r.reason} (<t:${Math.floor(r.createdAt.getTime() / 1000)}:d>, by <@${r.moderatorId}>)${r.active ? "" : "~~ (voided)"}`,
            )
            .join("\n"),
        );

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    if (sub === "remove") {
      const id = interaction.options.getInteger("id", true);
      const [updated] = await db
        .update(infractionsTable)
        .set({ active: false })
        .where(and(eq(infractionsTable.id, id), eq(infractionsTable.guildId, interaction.guild.id)))
        .returning();

      if (!updated) {
        await interaction.reply({ content: `No infraction found with ID #${id}.`, ephemeral: true });
        return;
      }

      await interaction.reply({ content: `Voided infraction #${id}.`, ephemeral: true });
    }
  },
};

export default command;
