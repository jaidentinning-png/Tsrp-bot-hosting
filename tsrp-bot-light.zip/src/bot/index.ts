import { Events } from "discord.js";
import { createBotClient } from "./client";
import { commands } from "./commands";
import { deployCommands } from "./deployCommands";
import { handleInteraction } from "./interactions";
import { logger } from "../lib/logger";

export async function startBot(): Promise<void> {
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    logger.warn("DISCORD_BOT_TOKEN not set — Discord bot will not start.");
    return;
  }

  const client = createBotClient();
  for (const command of commands) {
    client.commands.set(command.data.name, command);
  }

  client.once(Events.ClientReady, (readyClient) => {
    logger.info({ tag: readyClient.user.tag }, "TSRP Bot logged in");
  });

  client.on(Events.InteractionCreate, (interaction) => {
    void handleInteraction(client, interaction);
  });

  try {
    await deployCommands();
  } catch (err) {
    logger.error({ err }, "Failed to deploy slash commands");
  }

  await client.login(token);
}
